# 3D Portfolio Website

A modern, interactive portfolio website featuring 3D animations, scroll effects, and your personal branding.

## Features

- ✨ 3D interactive elements and floating animations
- 🎨 Custom color scheme matching your portrait
- 📱 Fully responsive design
- 🚀 Smooth scroll animations with intersection observers
- 💫 Framer Motion animations throughout
- 🎯 Modern React + TypeScript architecture
- 🎪 Glass morphism effects and gradient backgrounds

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```

3. **Open in Browser**
   - Visit `http://localhost:5000` to view your portfolio

## Project Structure

```
client/src/
├── components/
│   ├── ui/              # Reusable UI components (shadcn/ui)
│   ├── hero-section.tsx # Hero with portrait and 3D elements
│   ├── about-section.tsx # About section with interactive 3D
│   ├── skills-section.tsx # Skills with animated progress
│   ├── projects-section.tsx # Project showcase
│   ├── contact-section.tsx # Contact form with glass effects
│   ├── navigation.tsx   # Smooth scroll navigation
│   ├── scroll-indicator.tsx # Progress bar
│   └── three-scene.tsx  # 3D floating elements
├── hooks/               # Custom React hooks
├── lib/                 # Utilities and configurations
└── pages/               # Page components

server/                  # Express.js backend
shared/                  # Shared TypeScript types
attached_assets/         # Your portrait image and other assets
```

## Customization

### Personal Information
- Update contact details in `client/src/components/contact-section.tsx`
- Modify social links and personal info throughout components

### Styling
- Colors are defined in `client/src/index.css` and `tailwind.config.ts`
- The color scheme matches your vibrant portrait (orange/pink/navy)

### Content
- Edit project details in `client/src/components/projects-section.tsx`
- Update skills in `client/src/components/skills-section.tsx`
- Modify about text in `client/src/components/about-section.tsx`

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Animations**: Framer Motion, custom CSS animations
- **UI Components**: shadcn/ui with Radix primitives
- **Build Tool**: Vite
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured)

## Build for Production

```bash
npm run build
```

## Deploy

The application is ready for deployment on platforms like:
- Vercel
- Netlify  
- Replit Deployments
- Any Node.js hosting service

---

Built with ❤️ using modern web technologies