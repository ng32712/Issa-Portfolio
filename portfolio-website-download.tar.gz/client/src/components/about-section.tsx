import { motion } from 'framer-motion';
import { useIntersectionObserver } from '@/hooks/use-scroll';
import { Interactive3DElement } from './three-scene';
import { CheckCircle } from 'lucide-react';

export function AboutSection() {
  const [setRef, isVisible] = useIntersectionObserver();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  const highlights = [
    {
      title: "Creative Problem Solver",
      description: "I approach each project with fresh perspectives and innovative solutions."
    },
    {
      title: "Technology Enthusiast", 
      description: "Always exploring cutting-edge technologies and implementing best practices."
    },
    {
      title: "Detail Oriented",
      description: "Every pixel matters. I ensure perfection in both design and code."
    }
  ];

  return (
    <section 
      id="about" 
      className="py-20 bg-background"
      data-testid="about-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          ref={setRef}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          variants={containerVariants}
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
        >
          {/* Content */}
          <motion.div className="space-y-8" variants={itemVariants}>
            <div className="space-y-4">
              <h2 className="text-4xl md:text-6xl font-bold text-gradient">
                About Me
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                I'm a passionate creative developer who bridges the gap between stunning design and flawless functionality. 
                With expertise in modern web technologies and a keen eye for aesthetics, I create digital experiences that 
                captivate and engage.
              </p>
            </div>
            
            <div className="space-y-6">
              {highlights.map((highlight, index) => (
                <motion.div 
                  key={highlight.title}
                  className="flex items-start space-x-4"
                  variants={itemVariants}
                  transition={{ delay: index * 0.2 }}
                >
                  <CheckCircle className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {highlight.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {highlight.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* 3D Interactive Element */}
          <motion.div variants={itemVariants}>
            <Interactive3DElement />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
