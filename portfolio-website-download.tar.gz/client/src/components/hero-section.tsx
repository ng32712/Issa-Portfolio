import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useScrollIntoView } from '@/hooks/use-scroll';
import { ThreeScene } from './three-scene';
import { ChevronDown } from 'lucide-react';
import portraitImage from "@assets/Snapchat-467322694_1757099695961.jpg";

export function HeroSection() {
  const scrollToSection = useScrollIntoView();

  return (
    <section 
      id="hero" 
      className="min-h-screen relative overflow-hidden gradient-bg"
      data-testid="hero-section"
    >
      {/* 3D Background */}
      <ThreeScene />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 min-h-screen flex items-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center w-full">
          {/* Text Content */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="space-y-4">
              <motion.h1 
                className="text-5xl md:text-7xl font-bold text-white leading-tight"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                Creative
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-warm-yellow to-cream">
                  Developer
                </span>
              </motion.h1>
              <motion.p 
                className="text-xl md:text-2xl text-white/90 max-w-lg"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                Bringing ideas to life through innovative design and cutting-edge technology
              </motion.p>
            </div>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Button 
                className="px-8 py-4 bg-white text-primary font-semibold rounded-full hover:bg-white/90 transform hover:scale-105 transition-all duration-300 shadow-xl"
                onClick={() => scrollToSection('projects')}
                data-testid="button-view-work"
              >
                View My Work
              </Button>
              <Button 
                variant="outline"
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-primary transition-all duration-300"
                onClick={() => scrollToSection('contact')}
                data-testid="button-get-in-touch"
              >
                Get In Touch
              </Button>
            </motion.div>
          </motion.div>

          {/* Portrait Image */}
          <motion.div 
            className="relative"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
          >
            <motion.div 
              className="relative animate-float"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              {/* Portrait photo */}
              <div className="w-80 h-80 mx-auto relative">
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-br from-warm-yellow via-bright-pink to-navy-blue rounded-3xl rotate-6 animate-glow"
                  animate={{ rotate: [6, 8, 4, 6] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                />
                <img 
                  src={portraitImage} 
                  alt="Creative Developer Portrait" 
                  className="w-full h-full object-cover rounded-3xl relative z-10 shadow-2xl"
                  data-testid="portrait-image"
                />
              </div>
            </motion.div>
            
            {/* Floating Elements */}
            <motion.div 
              className="absolute -top-10 -right-10 w-20 h-20 bg-white/20 rounded-full"
              animate={{ 
                y: [0, -20, 0],
                rotate: [0, 180, 360]
              }}
              transition={{ 
                duration: 6, 
                repeat: Infinity,
                delay: 0.5,
                ease: "easeInOut"
              }}
            />
            <motion.div 
              className="absolute -bottom-5 -left-5 w-16 h-16 bg-warm-yellow/30 rounded-full"
              animate={{ 
                y: [0, -15, 0],
                scale: [1, 1.2, 1]
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity,
                delay: 1,
                ease: "easeInOut"
              }}
            />
            <motion.div 
              className="absolute top-1/2 -right-20 w-12 h-12 bg-bright-pink/30 rounded-full"
              animate={{ 
                y: [0, -10, 0],
                x: [0, 10, 0]
              }}
              transition={{ 
                duration: 5, 
                repeat: Infinity,
                delay: 1.5,
                ease: "easeInOut"
              }}
            />
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white cursor-pointer"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        onClick={() => scrollToSection('about')}
        data-testid="scroll-indicator"
      >
        <ChevronDown className="w-8 h-8" />
      </motion.div>
    </section>
  );
}
