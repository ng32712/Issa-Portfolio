import { motion } from 'framer-motion';
import { useIntersectionObserver } from '@/hooks/use-scroll';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Github } from 'lucide-react';

export function ProjectsSection() {
  const [setRef, isVisible] = useIntersectionObserver();

  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A full-stack e-commerce solution featuring real-time inventory, secure payments, and an intuitive admin dashboard. Built with React, Node.js, and MongoDB.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      technologies: ["React", "Node.js", "MongoDB", "Stripe API"],
      gradient: "from-primary to-secondary"
    },
    {
      title: "Fitness Tracking App", 
      description: "A comprehensive fitness application with workout tracking, progress analytics, and social features. Developed using React Native with real-time synchronization.",
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      technologies: ["React Native", "Firebase", "Redux", "Chart.js"],
      gradient: "from-secondary to-accent"
    },
    {
      title: "Analytics Dashboard",
      description: "An interactive data visualization platform with real-time analytics, custom reporting, and 3D chart representations. Built with D3.js and Three.js.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      technologies: ["Vue.js", "D3.js", "Three.js", "Python"],
      gradient: "from-accent to-primary"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 100 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 1,
        ease: "easeOut"
      }
    }
  };

  return (
    <section 
      id="projects" 
      className="py-20 bg-background"
      data-testid="projects-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-6xl font-bold text-gradient mb-6">
            Featured Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A showcase of my latest work combining creativity, technology, and user experience
          </p>
        </motion.div>

        <motion.div 
          ref={setRef}
          className="space-y-12"
          variants={containerVariants}
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
        >
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              className="group grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
              variants={itemVariants}
              data-testid={`project-${index}`}
            >
              <div 
                className={`relative overflow-hidden rounded-3xl shadow-2xl ${
                  index % 2 === 1 ? 'lg:order-2' : ''
                }`}
              >
                <motion.img 
                  src={project.image}
                  alt={`${project.title} Project`}
                  className="w-full h-96 object-cover transform transition-transform duration-700"
                  whileHover={{ scale: 1.1 }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              
              <div 
                className={`space-y-6 ${
                  index % 2 === 1 ? 'lg:order-1' : ''
                }`}
              >
                <div className="space-y-4">
                  <h3 className="text-3xl font-bold text-foreground">
                    {project.title}
                  </h3>
                  <p className="text-lg text-muted-foreground">
                    {project.description}
                  </p>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  {project.technologies.map((tech) => (
                    <Badge 
                      key={tech}
                      variant="secondary"
                      className={`px-4 py-2 bg-gradient-to-r ${project.gradient} text-white border-none`}
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex space-x-4">
                  <Button 
                    className={`px-6 py-3 bg-gradient-to-r ${project.gradient} text-white rounded-full font-medium hover:shadow-lg transition-all duration-300`}
                    data-testid={`view-project-${index}`}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Project
                  </Button>
                  <Button 
                    variant="outline"
                    className="px-6 py-3 border border-border text-foreground rounded-full font-medium hover:bg-muted transition-colors duration-300"
                    data-testid={`view-code-${index}`}
                  >
                    <Github className="w-4 h-4 mr-2" />
                    View Code
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
