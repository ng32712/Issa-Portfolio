import { useScrollProgress } from '@/hooks/use-scroll';

export function ScrollIndicator() {
  const progress = useScrollProgress();

  return (
    <div 
      className="fixed top-0 left-0 w-full h-1 bg-gradient-to-r from-vibrant-orange to-bright-pink z-50 transition-transform duration-300 ease-out origin-left"
      style={{ transform: `scaleX(${progress})` }}
      data-testid="scroll-indicator"
    />
  );
}
