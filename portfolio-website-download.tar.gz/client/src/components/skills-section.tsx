import { motion } from 'framer-motion';
import { useIntersectionObserver } from '@/hooks/use-scroll';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

export function SkillsSection() {
  const [setRef, isVisible] = useIntersectionObserver();

  const skills = [
    {
      icon: "⚡",
      title: "Frontend Development",
      description: "React, Vue.js, TypeScript, Tailwind CSS",
      proficiency: 95,
      color: "primary"
    },
    {
      icon: "🎨",
      title: "UI/UX Design",
      description: "Figma, Adobe Creative Suite, Prototyping",
      proficiency: 90,
      color: "secondary"
    },
    {
      icon: "🔧",
      title: "Backend Development",
      description: "Node.js, Python, PostgreSQL, MongoDB",
      proficiency: 85,
      color: "accent"
    },
    {
      icon: "📱",
      title: "Mobile Development",
      description: "React Native, Flutter, iOS/Android",
      proficiency: 80,
      color: "primary"
    },
    {
      icon: "🚀",
      title: "DevOps & Cloud",
      description: "AWS, Docker, CI/CD, Kubernetes",
      proficiency: 75,
      color: "secondary"
    },
    {
      icon: "🧠",
      title: "3D & Animation",
      description: "Three.js, WebGL, GSAP, Blender",
      proficiency: 88,
      color: "accent"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 80 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <section 
      id="skills" 
      className="py-20 bg-muted"
      data-testid="skills-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-6xl font-bold text-gradient mb-6">
            Skills & Expertise
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A diverse toolkit spanning design, development, and everything in between
          </p>
        </motion.div>

        <motion.div 
          ref={setRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
        >
          {skills.map((skill, index) => (
            <motion.div
              key={skill.title}
              variants={itemVariants}
              whileHover={{ 
                y: -8,
                transition: { duration: 0.3 }
              }}
              data-testid={`skill-card-${index}`}
            >
              <Card className="group bg-card rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 h-full">
                <CardContent className="p-0">
                  <motion.div 
                    className="text-4xl mb-4"
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.3 }}
                  >
                    {skill.icon}
                  </motion.div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">
                    {skill.title}
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    {skill.description}
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Proficiency</span>
                      <span className={`text-sm font-medium text-${skill.color}`}>
                        {skill.proficiency}%
                      </span>
                    </div>
                    <Progress 
                      value={skill.proficiency} 
                      className="h-2"
                      data-testid={`skill-progress-${index}`}
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
