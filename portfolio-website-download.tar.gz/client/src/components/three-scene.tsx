import { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

export function ThreeScene() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    // Since we're in a React environment, we'll use a simpler approach
    // In a full implementation, you'd use @react-three/fiber
    const container = mountRef.current;
    
    // Create floating geometric shapes using CSS animations
    const createFloatingShape = (shape: string, delay: number) => {
      const element = document.createElement('div');
      element.className = `absolute w-16 h-16 opacity-20 animate-float`;
      element.style.animationDelay = `${delay}s`;
      element.style.left = `${Math.random() * 80}%`;
      element.style.top = `${Math.random() * 80}%`;
      
      switch (shape) {
        case 'circle':
          element.style.borderRadius = '50%';
          element.style.background = 'linear-gradient(45deg, #FF6B35, #E91E63)';
          break;
        case 'square':
          element.style.background = 'linear-gradient(45deg, #E91E63, #1A237E)';
          break;
        case 'triangle':
          element.style.clipPath = 'polygon(50% 0%, 0% 100%, 100% 100%)';
          element.style.background = 'linear-gradient(45deg, #1A237E, #FF6B35)';
          break;
      }
      
      return element;
    };

    // Add floating shapes
    const shapes = ['circle', 'square', 'triangle'];
    for (let i = 0; i < 6; i++) {
      const shape = shapes[Math.floor(Math.random() * shapes.length)];
      const element = createFloatingShape(shape, i * 0.5);
      container.appendChild(element);
    }

    return () => {
      // Cleanup
      container.innerHTML = '';
    };
  }, []);

  return (
    <div 
      ref={mountRef} 
      className="absolute inset-0 overflow-hidden pointer-events-none"
      data-testid="three-scene"
    />
  );
}

export function Interactive3DElement() {
  return (
    <motion.div
      className="relative w-full h-96 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl p-8 overflow-hidden cursor-pointer"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      data-testid="interactive-3d-element"
    >
      <motion.div
        className="w-full h-full bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl flex items-center justify-center relative"
        whileHover={{ rotateY: 10, rotateX: -5 }}
        transition={{ duration: 0.3 }}
      >
        <div className="text-center space-y-4 z-10">
          <motion.div 
            className="text-6xl"
            animate={{ 
              rotate: [0, 10, -10, 0],
              y: [0, -10, 0]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            🚀
          </motion.div>
          <p className="text-lg font-medium text-foreground">Interactive 3D Experience</p>
          <p className="text-sm text-muted-foreground">Hover to explore</p>
        </div>
        
        {/* Floating particles */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-primary/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              delay: i * 0.3,
              ease: "easeInOut"
            }}
          />
        ))}
      </motion.div>
    </motion.div>
  );
}
