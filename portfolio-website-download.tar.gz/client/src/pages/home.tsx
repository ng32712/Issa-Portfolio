import { useEffect } from 'react';
import { Navigation } from '@/components/navigation';
import { ScrollIndicator } from '@/components/scroll-indicator';
import { HeroSection } from '@/components/hero-section';
import { AboutSection } from '@/components/about-section';
import { SkillsSection } from '@/components/skills-section';
import { ProjectsSection } from '@/components/projects-section';
import { ContactSection } from '@/components/contact-section';

export default function Home() {
  useEffect(() => {
    // Set page title and meta description
    document.title = "Creative Developer Portfolio - Interactive 3D Experience";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Modern 3D portfolio website showcasing creative development, design skills, and innovative projects with smooth animations and interactive Three.js elements.');
    }

    // Add Open Graph meta tags
    const ogTitle = document.createElement('meta');
    ogTitle.setAttribute('property', 'og:title');
    ogTitle.setAttribute('content', 'Creative Developer Portfolio');
    document.head.appendChild(ogTitle);

    const ogDescription = document.createElement('meta');
    ogDescription.setAttribute('property', 'og:description');
    ogDescription.setAttribute('content', 'Bringing ideas to life through innovative design and cutting-edge technology');
    document.head.appendChild(ogDescription);

    const ogType = document.createElement('meta');
    ogType.setAttribute('property', 'og:type');
    ogType.setAttribute('content', 'website');
    document.head.appendChild(ogType);

    // Cleanup function to remove meta tags when component unmounts
    return () => {
      document.head.removeChild(ogTitle);
      document.head.removeChild(ogDescription);
      document.head.removeChild(ogType);
    };
  }, []);

  return (
    <div className="min-h-screen" data-testid="home-page">
      <ScrollIndicator />
      <Navigation />
      
      <main>
        <HeroSection />
        <AboutSection />
        <SkillsSection />
        <ProjectsSection />
        <ContactSection />
      </main>
      
      <footer className="py-8 bg-foreground text-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm">
              &copy; {new Date().getFullYear()} Creative Portfolio. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
